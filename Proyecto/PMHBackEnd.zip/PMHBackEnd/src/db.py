from flask_sqlalchemy import SQLAlchemy

# Conexion con la base de datos

#mysql+pymysql://username:password@hostname:port/database

class DB:
    def __init__(self, app):
        self.database = 'pmh'
        self.hostname = '127.0.0.1'
        self.port = '3306'
        self.username = 'root'
        self.password = 'NeroDMC5'

        uri = 'mysql+pymysql://' + self.username + ':' + self.password
        uri += '@' + self.hostname + ':' + self.port
        uri += '/' + self.database
        app.config['SQLALCHEMY_DATABASE_URI'] = uri
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        self.db = SQLAlchemy(app)