from enum import unique
from flask import Flask, request, jsonify
from flask_marshmallow import Marshmallow
from sqlalchemy.orm import backref
from db import DB


app = Flask(__name__)
db = DB(app)
ma = Marshmallow(app)

# Definicion y Creacion llaves foraneas

class Perfil (db.db.Model):
    __tablename__ = 'perfil'
    idPerfil = db.db.Column(db.db.Integer, primary_key=True, autoincrement=True, unique=True)
    nombre = db.db.Column(db.db.String(50))
    apodo = db.db.Column(db.db.String(50), unique=True)
    correo = db.db.Column(db.db.String(50), unique=True)
    contraseña = db.db.Column(db.db.String(50))
    preguntas = db.db.relationship('Conversatorio', backref='persona')
    imagenes = db.db.relationship('Galeria', backref='persona')
    chats = db.db.relationship('Chat', backref='persona')
    
    
    def __init__(self, idPerfil, nombre, apodo, correo, contraseña, preguntas, imagenes, chats):
        self.idPerfil = idPerfil
        self.nombre = nombre
        self.apodo = apodo
        self.correo = correo
        self.contraseña = contraseña
        self.preguntas = preguntas
        self.imagenes = imagenes
        self.chats = chats

class Chat (db.db.Model):
    __tablename__ = 'chat'
    idChat = db.db.Column(db.db.Integer, primary_key=True, autoincrement=True)
    conversacion = db.db.Column(db.db.JSON)
    persona_id = db.db.Column(db.db.Integer, db.db.ForeignKey('perfil.id'))
    
    
    def __init__(self, idChat, conversacion, persona_id):
        self.idChat = idChat
        self.conversacion = conversacion
        self.persona_id = persona_id

class Galeria (db.db.Model):
    __tablename__ = 'galeria'
    idGaleria = db.db.Column(db.db.Integer, primary_key=True,)
    JPG = db.db.Column(db.db.BLOB)
    persona_id = db.db.Column(db.db.Integer, db.db.ForeignKey('perfil.id'))


    def __init__(self, idGaleria, JPG, persona_id):
        self.idGaleria = idGaleria
        self.JPG = JPG
        self.persona_id = persona_id 
        
class Conversatorio(db.db.Model):
    __tablename__ = 'conversatorio'
    idConversatorio = db.db.Column(db.db.Integer, primary_key=True, autoincrement=True)
    pregunta = db.db.Column(db.db.String(250))
    respuestas = db.db.relationship('Respuesta', backref='pregunta')
    persona_id = db.db.Column(db.db.Integer, db.db.ForeignKey('perfil.id'))  


    def __init__(self, idConversatorio, pregunta, persona_id):
        self.idConversatorio = idConversatorio
        self.pregunta = pregunta
        self.persona_id = persona_id
        
        
class Respuesta(db.db.Model):
    __tablename__ = 'respuesta'
    idRespuesta = db.db.Column(db.db.Integer, primary_key=True, autoincrement=True)
    respuesta = db.db.Column(db.db.String(250))
    pregunta_id = db.db.Column(db.db.Integer, db.db.ForeignKey('conversatorio.id'))
    
    
    def __init__(self, idRespuesta, respuesta, pregunta_id):
        self.idRespuesta = idRespuesta
        self.respuesta = respuesta
        self.pregunta_id = pregunta_id   
        
        
        
db.db.create_all()




if __name__ == "__main__":
    app.run(debug=True)

                 