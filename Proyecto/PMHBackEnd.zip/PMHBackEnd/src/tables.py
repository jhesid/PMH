from enum import unique
from flask import Flask, request, jsonify
from flask_marshmallow import Marshmallow
from sqlalchemy.orm import backref
from db import DB


app = Flask(__name__)
db = DB(app)
ma = Marshmallow(app)

# Definicion y Creacion de las tablas

class Perfil (db.db.Model):
    __tablename__ = 'perfil'
    idPerfil = db.db.Column(db.db.Integer, primary_key=True, autoincrement=True, unique=True)
    nombre = db.db.Column(db.db.String(50))
    apodo = db.db.Column(db.db.String(50), unique=True)
    correo = db.db.Column(db.db.String(50), unique=True)
    contraseña = db.db.Column(db.db.String(50))
    
    
    
    def __init__(self, idPerfil, nombre, apodo, correo, contraseña, preguntas, imagenes):
        self.idPerfil = idPerfil
        self.nombre = nombre
        self.apodo = apodo
        self.correo = correo
        self.contraseña = contraseña
        

class Chat (db.db.Model):
    __tablename__ = 'chat'
    idChat = db.db.Column(db.db.Integer, primary_key=True, autoincrement=True)
    conversacion = db.db.Column(db.db.JSON)
    
    
    
    def __init__(self, idChat, conversacion):
        self.idChat = idChat
        self.conversacion = conversacion
        

class Galeria (db.db.Model):
    __tablename__ = 'galeria'
    idGaleria = db.db.Column(db.db.Integer, primary_key=True,)
    JPG = db.db.Column(db.db.BLOB)
    


    def __init__(self, idGaleria, JPG):
        self.idGaleria = idGaleria
        self.JPG = JPG
        
        
class Conversatorio(db.db.Model):
    __tablename__ = 'conversatorio'
    idConversatorio = db.db.Column(db.db.Integer, primary_key=True, autoincrement=True)
    pregunta = db.db.Column(db.db.String(250))
    respuestas = db.db.relationship('Respuesta', backref='pregunta')
     


    def __init__(self, idConversatorio, pregunta):
        self.idConversatorio = idConversatorio
        self.pregunta = pregunta
       
        
        
class Respuesta(db.db.Model):
    __tablename__ = 'respuesta'
    idRespuesta = db.db.Column(db.db.Integer, primary_key=True, autoincrement=True)
    respuesta = db.db.Column(db.db.String(250))
    
    
    def __init__(self, idRespuesta, respuesta):
        self.idRespuesta = idRespuesta
        self.respuesta = respuesta
        
        
        
        
db.db.create_all()
